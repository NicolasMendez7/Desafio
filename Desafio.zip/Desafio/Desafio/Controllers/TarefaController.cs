using Desafio.Models;
using Desafio.Models.Enums;
using Microsoft.AspNetCore.Mvc;

namespace Desafio.Controllers
{
    [ApiController]
    [Route("tarefa")]
    public class TarefaController : ControllerBase
    {
        private static List<Tarefa> ListaTarefa { get; set; }

        public TarefaController()
        { }

        [HttpPost]
        public IActionResult IncluirTarefa([FromBody] Tarefa tarefa)
        {
            if (!tarefa.IsValid())
            {
                return BadRequest(new
                {
                    Erro = "Descricao Invalida"
                });
            }

            if (ListaTarefa == null) ListaTarefa = new();

            var proximoCodigo = ListaTarefa.Count == 0 ? 1 : ListaTarefa.Last().Codigo + 1;
            var item = new Tarefa(proximoCodigo, tarefa.Descricao);
            ListaTarefa.Add(item);

            return NoContent();
        }

        [HttpPut]
        public IActionResult AlterarTarefa([FromBody] Tarefa tarefa)
        {
            if (tarefa.Status != EnumStatus.C)
            {
                return BadRequest(new
                {
                    Erro = "Status n�o informado ou n�o permitido!"
                });
            }

            if (tarefa.Codigo == 0 || !ListaTarefa.Any(x => x.Codigo == tarefa.Codigo))
            {
                return NotFound(new
                {
                    Erro = "Tarefa n�o encontrada"
                });
            }

            if (!tarefa.IsValid())
            {
                return BadRequest(new
                {
                    Erro = "Descricao Invalida"
                });
            }

            var item = ListaTarefa.Where(x => x.Codigo == tarefa.Codigo).First();
            item.Descricao = tarefa.Descricao;
            item.Status = EnumStatus.C;

            return NoContent();
        }

        [HttpGet]
        public IActionResult ObterTarefas([FromQuery] int codigo)
        {
            if (codigo == 0)
            {
                return Ok(ListaTarefa);
            }

            if (!ListaTarefa.Any(x => x.Codigo == codigo))
            {
                return NotFound(new
                {
                    Erro = "Tarefa n�o encontrada"
                });
            }

            return Ok(ListaTarefa.Where(x => x.Codigo == codigo));
        }
    }
}
