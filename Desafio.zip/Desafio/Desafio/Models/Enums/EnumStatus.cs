﻿using System.Runtime.Serialization;

namespace Desafio.Models.Enums
{
    public enum EnumStatus
    {
        P,
        C
    }
}
