﻿using Desafio.Models.Enums;

namespace Desafio.Models
{
    public class Tarefa
    {
        public int Codigo { get; set; }
        public string Descricao { get; set; }
        public EnumStatus Status { get; set; }

        public Tarefa()
        { }

        public Tarefa(int codigo, string descricao)
        {
            Codigo = codigo;
            Descricao = descricao;
            Status = EnumStatus.P;
        }

        public bool IsValid()
        {
            return !string.IsNullOrWhiteSpace(this.Descricao);
        }
    }
}
